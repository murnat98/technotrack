#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "asm.h"

#endif // MAIN_H_INCLUDED
